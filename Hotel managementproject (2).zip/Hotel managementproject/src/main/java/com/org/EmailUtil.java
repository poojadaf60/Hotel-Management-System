package com.org;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailUtil {


    private static final String FROM_EMAIL = "poojadaf450@gmail.com";
    private static final String FROM_PASSWORD = "your-app-password"; // Gmail App Password
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "587";

    public static void sendBookingConfirmation(String toEmail, String customerName,
                                               int bookingId, String roomNo,
                                               String checkIn, String checkOut,
                                               double totalAmount) {
        String subject = "Booking Confirmation – Royal Palace Hotel";
        String body = buildEmailBody(customerName, bookingId, roomNo, checkIn, checkOut, totalAmount);
        sendEmail(toEmail, subject, body);
    }

    public static void sendEmail(String toEmail, String subject, String htmlBody) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.ssl.trust", SMTP_HOST);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(FROM_EMAIL, FROM_PASSWORD);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(FROM_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail));
            message.setSubject(subject);
            message.setContent(htmlBody, "text/html; charset=UTF-8");
            Transport.send(message);
            System.out.println("✅ Email sent to " + toEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("❌ Failed to send email: " + e.getMessage());
        }
    }

    private static String buildEmailBody(String customerName, int bookingId, String roomNo,
                                         String checkIn, String checkOut, double totalAmount) {
        return "<!DOCTYPE html>" +
                "<html>" +
                "<head><meta charset='UTF-8'></head>" +
                "<body style='font-family: Arial, sans-serif; background: #f4f6f9; padding: 20px;'>" +
                "<div style='max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);'>" +
                "<h2 style='color: #E3123D;'>🏨 Royal Palace Hotel</h2>" +
                "<h3 style='color: #273340;'>Booking Confirmation</h3>" +
                "<hr style='border: 1px solid #eee;'>" +
                "<p><strong>Dear " + customerName + ",</strong></p>" +
                "<p>Thank you for booking with us. Your reservation has been confirmed.</p>" +
                "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;'>" +
                "<p><strong>Booking ID:</strong> #" + bookingId + "</p>" +
                "<p><strong>Room Number:</strong> " + roomNo + "</p>" +
                "<p><strong>Check-In Date:</strong> " + checkIn + "</p>" +
                "<p><strong>Check-Out Date:</strong> " + checkOut + "</p>" +
                "<p><strong>Total Amount:</strong> ₹" + String.format("%.2f", totalAmount) + "</p>" +
                "</div>" +
                "<p style='color: #555;'>We look forward to welcoming you!</p>" +
                "<p style='color: #555; font-size: 14px;'>If you have any questions, please contact us at +91 9370482836</p>" +
                "<hr style='border: 1px solid #eee;'>" +
                "<p style='font-size: 12px; color: #999;'>© 2026 Royal Palace Hotel. All rights reserved.</p>" +
                "</div>" +
                "</body>" +
                "</html>";
    }
}